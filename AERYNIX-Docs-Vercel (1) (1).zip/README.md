# AERYNIX Docs

Static documentation website for the AERYNIX / AERX project.

## Files
- `index.html` — complete responsive documentation site
- `assets/aerynix-logo.png` — AERYNIX logo

## Open locally
Open `index.html` in a browser.

## Important
The current tokenomics, TGE target, reward schedule and fee model are project parameters, not guarantees. Final smart-contract rules should be audited and published before launch.
